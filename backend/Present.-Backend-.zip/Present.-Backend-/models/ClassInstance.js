const mongoose = require('mongoose');

const classInstanceSchema = new mongoose.Schema({
  teacherId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  instanceName: { type: String, required: true }, // e.g. "Monday Morning Algorithms"
  subjectName: { type: String, required: true },
  department: { type: String, required: true },
  year: { type: String, required: true },
  semester: { type: String, required: true },
  section: { type: String, required: true },
  classroom: { type: String, required: true },
  rollStart: { type: Number, required: true }, // e.g. 1
  rollEnd: { type: Number, required: true },   // e.g. 60
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('ClassInstance', classInstanceSchema, 'Teacher_Presets_DB');
