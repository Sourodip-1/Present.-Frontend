const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  role: { type: String, enum: ['student', 'teacher', 'admin', 'unknown'], default: 'unknown' },
  otp: { type: String },
  otpExpires: { type: Date },
  
  // Student Specific Data
  studentProfile: {
    fullName: String,
    universityRoll: String,
    semester: String,
    department: String,
    section: String,
    mainClassroom: String,
    studentId: String
  },

  // Teacher Specific Data
  teacherProfile: {
    fullName: String,
    designation: String
  },

  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('User', userSchema, 'System_Users_DB');
