const mongoose = require('mongoose');

const sessionSchema = new mongoose.Schema({
  teacherId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  classInstanceId: { type: mongoose.Schema.Types.ObjectId, ref: 'ClassInstance' }, // Link to preset
  teacherName: { type: String, required: true },
  subjectName: { type: String, required: true },
  department: { type: String, required: true },
  year: { type: String, required: true },
  semester: { type: String, required: true },
  section: { type: String, required: true },
  rollStart: { type: Number },
  rollEnd: { type: Number },
  classroom: { type: String },
  startTime: { type: Date, default: Date.now },
  isActive: { type: Boolean, default: true },
  broadcastId: { type: String, required: true },
  hardwareMajor: { type: Number } 
});

module.exports = mongoose.model('Session', sessionSchema, 'Live_Broadcasts_DB');
