require('dotenv').config();
const mongoose = require('mongoose');

mongoose.connect(process.env.MONGO_URI).then(async () => {
    try {
        console.log("🔥 INITIATING PRODUCTION DATA PURGE 🔥");
        
        // Drop existing unorganized collections
        await mongoose.connection.db.dropCollection('users').catch(e => console.log('Users already dropped'));
        await mongoose.connection.db.dropCollection('sessions').catch(e => console.log('Sessions already dropped'));
        await mongoose.connection.db.dropCollection('classinstances').catch(e => console.log('ClassInstances dropped'));
        await mongoose.connection.db.dropCollection('attendances').catch(e => console.log('Attendances dropped'));

        console.log("✅ All Hackathon Testing Data Annihilated.");
        console.log("Database is clean and ready for Production Schemas.");
        process.exit(0);
    } catch (err) {
        console.error("Purge Failed:", err);
        process.exit(1);
    }
});
