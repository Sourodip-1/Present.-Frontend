require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

// THE BRIDGE TO THE CLOUD
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ Connected to MongoDB Atlas Cloud!'))
  .catch(err => console.error('❌ Connection Error:', err));


const app = express();
const PORT = 3000;

// Security Middlemen Tools
app.use(cors()); // Instantly mathematically disables massive local network security walls so your React Native phone can illegally bypass firewalls and reach the laptop
app.use(express.json()); // Automatically instantly translates messy internet payloads into clean, readable Javascript JSON objects

app.get('/api/ping', (req, res) => {
  res.status(200).json({ status: 'Connected to Present. Cloud Server v1.0', timestamp: new Date() });
});


const Attendance = require('./models/Attendance');
const User = require('./models/User');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT),
  secure: process.env.SMTP_SECURE === 'true',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

// Verify SMTP connection on start
transporter.verify((error, success) => {
  if (error) {
    console.log('❌ SMTP Configuration Error:', error);
  } else {
    console.log('📬 [SMTP READY] Server is successfully prepared to deliver emails.');
  }
});

// --- AUTH ROUTES ---

// 1. Send OTP (Generate and Email it)
app.post('/api/auth/send-otp', async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'Email is required' });

  const otp = Math.floor(100000 + Math.random() * 900000).toString(); // Generate 6-digit code
  const expiry = new Date(Date.now() + 5 * 60 * 1000); // 5 minute expiry

  try {
    // Save/Update user in DB
    await User.findOneAndUpdate(
      { email },
      { otp, otpExpires: expiry },
      { upsert: true, returnDocument: 'after' }
    );

    // Send Email
    const mailOptions = {
      from: `"Present. App" <${process.env.SMTP_USER}>`,
      to: email,
      subject: 'Your Present. Login Code',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 500px; margin: 0 auto; color: #1E293B; border: 1px solid #E2E8F0; border-radius: 12px; overflow: hidden;">
          <div style="background-color: #2563EB; padding: 25px; text-align: center;">
            <h1 style="color: #FFF; margin: 0; font-size: 24px;">Present.</h1>
          </div>
          <div style="padding: 30px; text-align: center;">
            <p style="font-size: 16px; margin-bottom: 30px;">Your secure verification code is below. It expires in 5 minutes.</p>
            <div style="background-color: #F8FAFC; border: 1px solid #E2E8F0; padding: 15px; border-radius: 8px; display: inline-block;">
              <h2 style="font-size: 32px; color: #2563EB; letter-spacing: 6px; margin: 0;">${otp}</h2>
            </div>
          </div>
        </div>
      `,
    };

    const info = await transporter.sendMail(mailOptions);
    
    // AUTH SIMULATION: Shows the code in your terminal so you can use it instantly for testing
    console.log(`\n-----------------------------------`);
    console.log(`📧 [OTP SENT] Code for ${email}: ${otp}`);
    console.log(`📧 [SENDER_RESPONSE] ID: ${info.messageId}`);
    console.log(`-----------------------------------\n`);
    
    res.status(200).json({ success: true, message: 'OTP emailed successfully.' });
  } catch (err) {
    console.error('❌ [OTP Error]:', err);
    res.status(500).json({ error: 'Failed to generate and send OTP. Check server logs.' });
  }
});

// 2. Verify OTP
app.post('/api/auth/verify-otp', async (req, res) => {
  const { email, code } = req.body;
  console.log(`🔑 [VERIFY_ATTEMPT] Email: ${email}, Code: ${code}`);
  try {
    const user = await User.findOne({ email });

    if (!user || user.otp !== code || user.otpExpires < new Date()) {
      return res.status(400).json({ error: 'Invalid or expired OTP' });
    }

    // Clear OTP after success
    user.otp = undefined;
    user.otpExpires = undefined;
    await user.save();

    res.status(200).json({ 
      success: true, 
      isNewUser: user.role === 'unknown',
      role: user.role,
      message: 'Logged in!' 
    });
  } catch (err) {
    res.status(500).json({ error: 'Verification failed' });
  }
});

// 3. Register Profile (Onboarding)
app.post('/api/auth/register-profile', async (req, res) => {
  const { email, role, profile, teacherCode } = req.body;
  console.log(`📝 [REGISTER_ATTEMPT] Email: ${email}, Role: ${role}`);
  try {
    // SECURITY: If they want to be a teacher, check the secret code!
    if (role === 'teacher') {
      const SECRET_CODE = "PRES-TEACH-2026"; // You can change this later!
      if (teacherCode !== SECRET_CODE) {
        return res.status(403).json({ error: 'Invalid Teacher Verification Code!' });
      }
    }

    let user = await User.findOne({ email });
    if (!user) {
      user = new User({ email, role });
    } else {
      user.role = role;
    }
    
    if (role === 'student' && profile) {
      user.studentProfile = profile;
    } 
    if (role === 'teacher' && profile) {
      user.teacherProfile = profile;
    }

    await user.save();

    console.log(`👤 [PROFILE SAVED] ${role} profile nested for ${email}`);
    res.status(200).json({ success: true, user });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to save profile' });
  }
});

// 4. Get User Profile Data
app.get('/api/users/:email', async (req, res) => {
  try {
    const user = await User.findOne({ email: req.params.email });
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.status(200).json(user);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch user' });
  }
});

// --- SESSION ROUTES ---
const Session = require('./models/Session');
const ClassInstance = require('./models/ClassInstance');

// A. Create/Save a Class Instance (Preset)
app.post('/api/instances/create', async (req, res) => {
  const { email, instanceName, subjectName, department, year, semester, section, classroom, rollStart, rollEnd } = req.body;
  try {
    const teacher = await User.findOne({ email, role: 'teacher' });
    if (!teacher) return res.status(403).json({ error: 'Unauthorized' });

    const newInstance = new ClassInstance({
      teacherId: teacher._id,
      instanceName,
      subjectName,
      department,
      year,
      semester,
      section,
      classroom,
      rollStart,
      rollEnd
    });

    await newInstance.save();
    res.status(201).json({ success: true, instance: newInstance });
  } catch (err) {
    res.status(500).json({ error: 'Failed to save instance' });
  }
});

// B. Fetch All Saved Instances for a Teacher
app.get('/api/instances/:email', async (req, res) => {
  try {
    const teacher = await User.findOne({ email: req.params.email, role: 'teacher' });
    if (!teacher) return res.status(404).json({ error: 'Teacher not found' });

    const instances = await ClassInstance.find({ teacherId: teacher._id }).sort({ createdAt: -1 });
    res.status(200).json(instances);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch instances' });
  }
});

// C. Fetch History of Sessions for a specific Instance
app.get('/api/instances/:instanceId/history', async (req, res) => {
  try {
    const sessionsList = await Session.find({ classInstanceId: req.params.instanceId }).sort({ startTime: -1 }).lean();
    
    for (let s of sessionsList) {
      s.presentCount = await Attendance.countDocuments({ sessionId: s._id });
    }
    
    res.status(200).json(sessionsList);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch history' });
  }
});

// D. Get Full Report for a Specific Session
app.get('/api/sessions/:sessionId/report', async (req, res) => {
  try {
    const session = await Session.findById(req.params.sessionId);
    if (!session) return res.status(404).json({ error: 'Session not found' });

    const attendanceLogs = await Attendance.find({ sessionId: session._id }).populate('studentId', 'studentProfile email');
    
    // Calculate Stats
    const totalExpected = (session.rollEnd - session.rollStart) + 1;
    const presentCount = attendanceLogs.length;
    const percentage = totalExpected > 0 ? (presentCount / totalExpected) * 100 : 0;

    res.status(200).json({
      sessionInfo: session,
      stats: {
        totalExpected,
        presentCount,
        absentCount: Math.max(0, totalExpected - presentCount),
        percentage: percentage.toFixed(2)
      },
      presentStudents: attendanceLogs.map(log => ({
        name: log.studentId?.fullName || 'Anonymous',
        rollNo: log.studentId?.studentProfile?.universityRoll || '000',
        time: log.timestamp
      }))
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to generate report' });
  }
});

// E. Mark Attendance (Student Joins Session)
app.post('/api/attendance/mark', async (req, res) => {
  const { sessionId, studentEmail } = req.body;

  try {
    const session = await Session.findById(sessionId);
    if (!session || !session.isActive) {
      return res.status(404).json({ error: 'Session is no longer active' });
    }

    const student = await User.findOne({ email: studentEmail, role: 'student' });
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    // --- 3-DIGIT ROLL SLICING LOGIC ---
    const fullRoll = student.studentProfile.universityRoll; 
    const rollSuffix = parseInt(fullRoll.slice(-3)); // Take last 3 digits, convert to number

    // --- STRICT SECTION VALIDATION ---
    const studentSec = student.studentProfile.section?.trim().toUpperCase() || '';
    const teacherSec = session.section?.trim().toUpperCase() || '';
    
    if (studentSec && teacherSec && studentSec !== teacherSec) {
      return res.status(403).json({ 
        error: `Section Mismatch! You are in Sec ${student.studentProfile.section}. This class is strictly for Sec ${session.section}.` 
      });
    }

    // Verify if student is in the Teacher's expected range
    if (rollSuffix < session.rollStart || rollSuffix > session.rollEnd) {
      return res.status(403).json({ 
        error: `Your roll (${rollSuffix}) is out of range for this class (${session.rollStart}-${session.rollEnd})` 
      });
    }

    // Check for Duplicate Attendance
    const existing = await Attendance.findOne({ sessionId, studentId: student._id });
    if (existing) {
      return res.status(400).json({ error: 'Attendance already marked for this class' });
    }

    const newLog = new Attendance({
      sessionId: session._id,
      studentId: student._id
    });

    await newLog.save();
    res.status(201).json({ success: true, message: 'Attendance marked successfully!' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to mark attendance' });
  }
});

// F. End a Session (Teacher stops class)
app.put('/api/sessions/:id/end', async (req, res) => {
  try {
    const session = await Session.findByIdAndUpdate(
      req.params.id, 
      { isActive: false }, 
      { new: true }
    );
    if (!session) return res.status(404).json({ error: 'Session not found' });
    res.status(200).json({ success: true, message: 'Session turned off.' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to end session' });
  }
});

// Delete a Preset (Class Instance)
app.delete('/api/instances/:id', async (req, res) => {
  try {
    const instance = await ClassInstance.findByIdAndDelete(req.params.id);
    if (!instance) return res.status(404).json({ error: 'Preset not found' });
    res.status(200).json({ success: true, message: 'Preset deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete preset' });
  }
});

// H. Fetch Records for a Specific Student (Supports Calendar Date Filter)
app.get('/api/records/student/:email', async (req, res) => {
  const { date } = req.query; // e.g. 2024-03-25
  try {
    const student = await User.findOne({ email: req.params.email, role: 'student' });
    if (!student) return res.status(404).json({ error: 'User not found' });

    let query = { studentId: student._id };

    // If a specific date is requested, filter the timestamp range
    if (date) {
      const start = new Date(date);
      start.setHours(0, 0, 0, 0);
      const end = new Date(date);
      end.setHours(23, 59, 59, 999);
      query.timestamp = { $gte: start, $lte: end };
    }

    const logs = await Attendance.find(query)
      .populate({
        path: 'sessionId',
        select: 'subjectName teacherName startTime department'
      })
      .sort({ timestamp: -1 });

    // Calculate Subject-wise stats (Always return overall stats for the dashboard)
    const allLogs = await Attendance.find({ studentId: student._id }).populate('sessionId', 'subjectName');
    const stats = {};
    allLogs.forEach(log => {
      const subj = log.sessionId.subjectName;
      if (!stats[subj]) stats[subj] = 0;
      stats[subj]++;
    });

    res.status(200).json({
      history: logs,
      subjectStats: stats
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch student records' });
  }
});

// G. Identity Lookup (BLE Code -> Cloud Profile)
app.get('/api/sessions/lookup/:major', async (req, res) => {
  try {
    const session = await Session.findOne({ hardwareMajor: parseInt(req.params.major), isActive: true });
    if (!session) return res.status(404).json({ error: 'Ghost session detected' });
    res.status(200).json(session);
  } catch (err) {
    res.status(500).json({ error: 'Lookup failed' });
  }
});

// 1. Create a Session (Teacher Starts Class)
app.post('/api/sessions/create', async (req, res) => {
  const { email, subjectName, department, year, semester, section, classroom, rollStart, rollEnd, classInstanceId, broadcastId } = req.body;

  try {
    const teacher = await User.findOne({ email, role: 'teacher' });
    if (!teacher) {
      return res.status(403).json({ error: 'Only registered teachers can start sessions' });
    }

    // Generate a unique Hardware ID for the BLE packet (0-65535)
    const hardwareMajor = Math.floor(Math.random() * 65000);

    const newSession = new Session({
      teacherId: teacher._id,
      classInstanceId,
      teacherName: teacher.teacherProfile?.fullName || 'Unknown Teacher',
      subjectName,
      department,
      year,
      semester,
      section,
      rollStart,
      rollEnd,
      classroom,
      broadcastId,
      hardwareMajor
    });

    await newSession.save();
    res.status(201).json(newSession); // Return the full object so teacher knows their hardwareMajor
  } catch (err) {
    res.status(500).json({ error: 'Failed to create session' });
  }
});

// 2. Get Active Sessions (Students see what's happening)
app.get('/api/sessions/active', async (req, res) => {
  try {
    const activeSessions = await Session.find({ isActive: true }).sort({ startTime: -1 });
    console.log(`📡 [ACTIVE_SESSIONS] Request received. Found ${activeSessions.length} active session(s).`);
    if (activeSessions.length > 0) {
      activeSessions.forEach(s => console.log(`   ▸ ${s.subjectName} | isActive: ${s.isActive} | ID: ${s._id}`));
    }
    res.status(200).json(activeSessions);
  } catch (err) {
    console.error('❌ [ACTIVE_SESSIONS] Error:', err);
    res.status(500).json({ error: 'Failed to fetch sessions' });
  }
});


app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 [BACKEND ONLINE] Waiter API is actively successfully listening on port ${PORT}`);
});
